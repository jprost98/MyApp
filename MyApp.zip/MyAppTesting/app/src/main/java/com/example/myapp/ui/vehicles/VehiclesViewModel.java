package com.example.myapp.ui.vehicles;

import androidx.lifecycle.ViewModel;

public class VehiclesViewModel extends ViewModel {

    public VehiclesViewModel() {

    }
}