package com.example.myapp.ui.home;

import androidx.lifecycle.ViewModel;

public class HomeViewModel extends ViewModel {

    public HomeViewModel() {

    }
}