package com.example.myapp.ui.settings;

import androidx.lifecycle.ViewModel;

public class SettingsViewModel extends ViewModel {

    public SettingsViewModel() {
        
    }
}