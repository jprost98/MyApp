package com.example.myapp.ui.checkup;

import androidx.lifecycle.ViewModel;

public class CheckupViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}